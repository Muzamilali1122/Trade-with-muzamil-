'use client';

import React, { useState, useEffect, useRef } from "react";

const palette = {
  navy: "#06101F",
  deepBlue: "#0B1E3D",
  cyan: "#22D3EE",
  electric: "#2F6FED",
  violet: "#7C5CFC",
  gold: "#C9A24B",
};

function useTicker() {
  const [price, setPrice] = useState(2518.46);
  const [dir, setDir] = useState(1);
  useEffect(() => {
    const id = setInterval(() => {
      setPrice((p) => {
        const delta = (Math.random() - 0.48) * 1.2;
        setDir(delta >= 0 ? 1 : -1);
        return Math.max(2400, p + delta);
      });
    }, 1800);
    return () => clearInterval(id);
  }, []);
  return { price, dir };
}

function NavBar({ active, onNav }) {
  const links = [
    "Home",
    "AI Tools",
    "Education",
    "Insights",
    "Strategies",
    "Community",
    "VIP",
    "Partners",
    "About",
    "FAQ",
    "Contact",
  ];
  const [open, setOpen] = useState(false);
  return (
    <header className="sticky top-0 z-50 backdrop-blur-md bg-[#06101f]/85 border-b border-white/5">
      <div className="max-w-7xl mx-auto flex items-center justify-between px-5 py-4">
        <button onClick={() => onNav("Home")} className="flex items-center gap-2 group">
          <span className="relative w-8 h-8 rounded-full border border-cyan-400/60 grid place-items-center">
            <span className="w-2 h-2 rounded-full bg-cyan-400 group-hover:scale-125 transition-transform" />
          </span>
          <span className="font-semibold tracking-tight text-slate-100 leading-none">
            Trade With <span style={{ color: palette.gold }}>Muzamil</span>
          </span>
        </button>
        <nav className="hidden lg:flex items-center gap-6 text-[13px] text-slate-300">
          {links.map((l) => (
            <button
              key={l}
              onClick={() => onNav(l)}
              className={`transition-colors hover:text-cyan-300 ${
                active === l ? "text-cyan-300" : ""
              }`}
            >
              {l}
            </button>
          ))}
        </nav>
        <div className="hidden md:flex items-center gap-3">
          <button className="text-[13px] px-4 py-2 rounded-full border border-white/15 text-slate-200 hover:border-cyan-400/60 transition-colors">
            Free Course
          </button>
          <button
            className="text-[13px] px-4 py-2 rounded-full font-medium text-[#0B1E3D]"
            style={{ background: `linear-gradient(120deg, ${palette.gold}, #E8CE8A)` }}
          >
            VIP Access
          </button>
        </div>
        <button className="lg:hidden text-slate-200" onClick={() => setOpen((o) => !o)}>
          {open ? "✕" : "☰"}
        </button>
      </div>
      {open && (
        <div className="lg:hidden px-5 pb-4 flex flex-col gap-3 text-slate-300 text-sm">
          {links.map((l) => (
            <button key={l} className="text-left" onClick={() => { onNav(l); setOpen(false); }}>
              {l}
            </button>
          ))}
        </div>
      )}
    </header>
  );
}

function LiveSession() {
  const { price, dir } = useTicker();
  return (
    <div className="rounded-2xl border border-white/10 bg-gradient-to-b from-[#0B1E3D] to-[#071427] p-5 shadow-[0_0_60px_-15px_rgba(34,211,238,0.25)]">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2 text-[11px] text-cyan-300">
          <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
          DEMO SESSION · XAUUSD · M15
        </div>
        <span className="text-[10px] text-slate-500">Illustrative data — not live</span>
      </div>
      <div className="flex items-end justify-between mb-4">
        <div>
          <div className="text-3xl font-semibold text-slate-100 tabular-nums">
            {price.toFixed(2)}
          </div>
          <div className={`text-xs mt-1 ${dir > 0 ? "text-emerald-400" : "text-rose-400"}`}>
            {dir > 0 ? "▲" : "▼"} demo movement, not a live quote
          </div>
        </div>
        <div className="text-right text-[11px] text-slate-400 leading-5">
          <div>Support <b className="text-slate-200">2,512</b></div>
          <div>Resistance <b className="text-slate-200">2,524</b></div>
        </div>
      </div>
      <svg viewBox="0 0 400 100" className="w-full h-24">
        <path
          d="M0 70 C30 55 55 65 80 50 S130 60 155 42 S205 55 230 35 S280 48 305 28 S355 40 400 20"
          fill="none"
          stroke="url(#g1)"
          strokeWidth="3"
        />
        <defs>
          <linearGradient id="g1" x1="0" x2="1">
            <stop offset="0" stopColor={palette.cyan} />
            <stop offset="1" stopColor={palette.violet} />
          </linearGradient>
        </defs>
      </svg>
      <div className="mt-4 rounded-xl bg-black/30 border border-white/5 px-4 py-3 flex items-center justify-between">
        <span className="text-[11px] text-slate-400">AI Scenario</span>
        <span className="text-xs font-medium text-amber-300">WAIT FOR CONFIRMATION</span>
      </div>
    </div>
  );
}

function Section({ id, kicker, title, children, dark }) {
  return (
    <section id={id} className={`px-5 py-20 ${dark ? "bg-[#050c18]" : ""}`}>
      <div className="max-w-6xl mx-auto">
        {kicker && (
          <div className="text-cyan-300/80 text-[13px] mb-3">{kicker}</div>
        )}
        {title && (
          <h2 className="text-2xl md:text-3xl font-semibold text-slate-100 mb-8 max-w-xl">
            {title}
          </h2>
        )}
        {children}
      </div>
    </section>
  );
}

const aiTools = [
  { name: "AI Trading Assistant", desc: "Explains structure, levels and scenarios in plain language as you review a chart." },
  { name: "XAUUSD Signal Engine", desc: "Generates BUY / SELL / WAIT scenarios with entry, stop-loss and take-profit for Gold on M15." },
  { name: "Risk Manager", desc: "Calculates position size and risk/reward before you place a trade." },
  { name: "Trading Journal", desc: "Logs every trade with notes, screenshots and outcome for honest review." },
  { name: "Performance Dashboard", desc: "Tracks win rate, drawdown and consistency over time." },
  { name: "AI Client Support Agent", desc: "Answers platform questions in English, Urdu and Spanish, any time." },
];

export default function PublicSite() {
  const [active, setActive] = useState("Home");
  const refs = useRef({});

  const onNav = (label) => {
    setActive(label);
    const id = label.toLowerCase().replace(/\s+/g, "-");
    refs.current[id]?.scrollIntoView({ behavior: "smooth" });
  };

  const setRef = (id) => (el) => (refs.current[id] = el);

  return (
    <div className="min-h-screen bg-[#06101F] text-slate-200 font-[Inter,system-ui,sans-serif]">
      <NavBar active={active} onNav={onNav} />

      {/* HOME / HERO */}
      <div id="home" ref={setRef("home")} className="relative overflow-hidden">
        <div
          className="absolute inset-0 opacity-40"
          style={{
            background:
              "radial-gradient(600px 300px at 20% 0%, rgba(124,92,252,0.25), transparent), radial-gradient(500px 260px at 90% 10%, rgba(34,211,238,0.18), transparent)",
          }}
        />
        <div className="relative max-w-7xl mx-auto px-5 pt-16 pb-24 grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <div className="inline-flex items-center gap-2 text-[11px] text-cyan-300 border border-cyan-400/30 rounded-full px-3 py-1 mb-6">
              <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" /> AI-assisted trading education
            </div>
            <h1 className="text-4xl md:text-5xl font-semibold text-slate-50 leading-[1.1] mb-5">
              Trade with structure,
              <br /> not guesswork.
            </h1>
            <p className="text-slate-400 max-w-md mb-8 leading-relaxed">
              An AI-powered command center for Gold trading — education, market
              structure, journaling and disciplined decision-making in one place.
            </p>
            <div className="flex flex-wrap gap-3">
              <button
                onClick={() => onNav("AI Tools")}
                className="px-5 py-3 rounded-full text-[#06101F] font-medium"
                style={{ background: `linear-gradient(120deg, ${palette.cyan}, ${palette.electric})` }}
              >
                Explore AI Tools →
              </button>
              <button
                onClick={() => onNav("Education")}
                className="px-5 py-3 rounded-full border border-white/15 text-slate-200"
              >
                Start Free Course →
              </button>
            </div>
            <p className="text-[11px] text-slate-500 mt-6">
              Educational content only · Markets involve risk · No guaranteed outcomes
            </p>
          </div>
          <LiveSession />
        </div>
      </div>

      {/* AI TOOLS */}
      <Section
        id="ai-tools"
        kicker="AI COMMAND CENTER"
        title="Six tools built to remove guesswork from every decision"
        dark
      >
        <div ref={setRef("ai-tools")} className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {aiTools.map((t) => (
            <div
              key={t.name}
              className="rounded-2xl border border-white/8 bg-white/[0.02] p-5 hover:border-cyan-400/30 transition-colors"
            >
              <div className="text-slate-100 font-medium mb-2">{t.name}</div>
              <p className="text-[13px] text-slate-400 leading-relaxed">{t.desc}</p>
            </div>
          ))}
        </div>
        <p className="text-[11px] text-slate-500 mt-6">
          Signal generation only in this phase — MT5 execution will ship as a
          clearly labelled, opt-in integration once security review is complete.
        </p>
      </Section>

      {/* EDUCATION */}
      <Section
        id="education"
        kicker="LEARN THE PROCESS"
        title="A learning path built around discipline, not shortcuts"
      >
        <div ref={setRef("education")} className="grid md:grid-cols-2 gap-8 items-center">
          <div className="grid grid-cols-2 gap-3">
            {["Beginner Trading", "Technical Analysis", "Price Action", "Market Structure", "Risk Management", "Trading Psychology"].map(
              (l) => (
                <div key={l} className="rounded-xl border border-white/8 px-4 py-3 text-[13px] text-slate-300">
                  {l}
                </div>
              )
            )}
          </div>
          <p className="text-slate-400 leading-relaxed">
            Go from foundations to advanced market structure with a practical
            path that rewards process over promises — every lesson ties back to
            a habit you can actually keep on a live chart.
          </p>
        </div>
      </Section>

      {/* INSIGHTS */}
      <Section id="insights" kicker="MARKET INTELLIGENCE" title="Market structure, not false certainty" dark>
        <div ref={setRef("insights")} className="flex flex-wrap gap-3 mb-4">
          {["XAUUSD", "EURUSD", "BTCUSD", "NAS100"].map((m) => (
            <span key={m} className="text-[12px] px-3 py-1.5 rounded-full border border-white/10 text-slate-300">
              {m}
            </span>
          ))}
        </div>
        <p className="text-slate-400 max-w-lg">
          Every view separates scenarios, levels and risk factors from
          guarantees — because certainty isn't something any market offers.
        </p>
      </Section>

      {/* CONTACT / FOOTER */}
      <Section id="contact" kicker="GET IN TOUCH" title="Questions, partnerships or platform support?">
        <div ref={setRef("contact")} className="max-w-md">
          <div className="grid gap-3">
            <input placeholder="Your name" className="bg-white/[0.03] border border-white/10 rounded-xl px-4 py-3 text-sm outline-none focus:border-cyan-400/50" />
            <input placeholder="Email address" className="bg-white/[0.03] border border-white/10 rounded-xl px-4 py-3 text-sm outline-none focus:border-cyan-400/50" />
            <textarea placeholder="Your message" rows={4} className="bg-white/[0.03] border border-white/10 rounded-xl px-4 py-3 text-sm outline-none focus:border-cyan-400/50" />
            <button
              className="px-5 py-3 rounded-full text-[#06101F] font-medium self-start"
              style={{ background: `linear-gradient(120deg, ${palette.cyan}, ${palette.electric})` }}
            >
              Send Message →
            </button>
          </div>
        </div>
      </Section>

      <footer className="border-t border-white/5 px-5 py-8 text-center text-[11px] text-slate-500">
        © 2026 Trade With Muzamil. Educational content and AI analysis are not financial advice.
      </footer>
    </div>
  );
}
