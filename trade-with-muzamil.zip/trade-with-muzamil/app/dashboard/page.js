import CommandCenter from "./CommandCenter";

export default function DashboardPage() {
  return <CommandCenter />;
}
