'use client';

import React, { useState, useEffect, useRef } from "react";

const palette = {
  navy: "#06101F",
  deepBlue: "#0B1E3D",
  cyan: "#22D3EE",
  electric: "#2F6FED",
  violet: "#7C5CFC",
  gold: "#C9A24B",
};

function useDemoPrice() {
  const [price, setPrice] = useState(2518.46);
  const [history, setHistory] = useState(() =>
    Array.from({ length: 40 }, (_, i) => 2518 + Math.sin(i / 3) * 4)
  );
  useEffect(() => {
    const id = setInterval(() => {
      setPrice((p) => {
        const next = Math.max(2400, p + (Math.random() - 0.48) * 1.4);
        setHistory((h) => [...h.slice(1), next]);
        return next;
      });
    }, 2200);
    return () => clearInterval(id);
  }, []);
  return { price, history };
}

function useDemoSignal(price) {
  const [signal, setSignal] = useState({
    type: "WAIT",
    entry: null,
    sl: null,
    tp: null,
    rr: null,
    note: "Waiting for structure confirmation.",
  });
  useEffect(() => {
    const id = setInterval(() => {
      const roll = Math.random();
      if (roll > 0.72) {
        const entry = price;
        const sl = +(entry - 4.2).toFixed(2);
        const tp = +(entry + 8.4).toFixed(2);
        setSignal({
          type: "BUY",
          entry: entry.toFixed(2),
          sl,
          tp,
          rr: "1 : 2",
          note: "Demo scenario — bullish structure on M15 (illustrative only).",
        });
      } else if (roll > 0.5) {
        const entry = price;
        const sl = +(entry + 4.2).toFixed(2);
        const tp = +(entry - 8.4).toFixed(2);
        setSignal({
          type: "SELL",
          entry: entry.toFixed(2),
          sl,
          tp,
          rr: "1 : 2",
          note: "Demo scenario — bearish structure on M15 (illustrative only).",
        });
      } else {
        setSignal({
          type: "WAIT",
          entry: null,
          sl: null,
          tp: null,
          rr: null,
          note: "No clear confirmation yet — standing by.",
        });
      }
    }, 9000);
    return () => clearInterval(id);
  }, [price]);
  return signal;
}

function Sparkline({ data }) {
  const w = 300, h = 60;
  const min = Math.min(...data), max = Math.max(...data);
  const pts = data
    .map((v, i) => {
      const x = (i / (data.length - 1)) * w;
      const y = h - ((v - min) / (max - min || 1)) * h;
      return `${x},${y}`;
    })
    .join(" ");
  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="w-full h-14">
      <polyline points={pts} fill="none" stroke={palette.cyan} strokeWidth="2" />
    </svg>
  );
}

function Card({ title, children, className = "" }) {
  return (
    <div className={`rounded-2xl border border-white/8 bg-white/[0.02] p-5 ${className}`}>
      <div className="text-[13px] text-slate-400 mb-3">{title}</div>
      {children}
    </div>
  );
}

function SignalBadge({ type }) {
  const styles = {
    BUY: "bg-emerald-400/15 text-emerald-300 border-emerald-400/30",
    SELL: "bg-rose-400/15 text-rose-300 border-rose-400/30",
    WAIT: "bg-amber-400/15 text-amber-300 border-amber-400/30",
  };
  return (
    <span className={`text-xs font-medium px-3 py-1 rounded-full border ${styles[type]}`}>
      {type}
    </span>
  );
}

export default function CommandCenter() {
  const { price, history } = useDemoPrice();
  const signal = useDemoSignal(price);
  const [journal, setJournal] = useState([]);
  const [watchlist] = useState(["XAUUSD", "EURUSD", "BTCUSD", "NAS100"]);
  const [balance, setBalance] = useState(10000);
  const [riskPct, setRiskPct] = useState(1);
  const [stopPips, setStopPips] = useState(20);

  const riskAmount = (balance * riskPct) / 100;
  const lotSize = stopPips > 0 ? (riskAmount / (stopPips * 10)).toFixed(2) : "0.00";

  const logTrade = () => {
    if (signal.type === "WAIT") return;
    setJournal((j) => [
      {
        id: Date.now(),
        type: signal.type,
        entry: signal.entry,
        sl: signal.sl,
        tp: signal.tp,
        time: new Date().toLocaleTimeString(),
      },
      ...j,
    ].slice(0, 8));
  };

  return (
    <div className="min-h-screen bg-[#06101F] text-slate-200 font-[Inter,system-ui,sans-serif] p-5">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-xl font-semibold text-slate-100">AI Command Center</h1>
            <p className="text-[12px] text-slate-500">
              Trade With Muzamil · Demo mode — no live broker connection
            </p>
          </div>
          <span className="text-[11px] px-3 py-1.5 rounded-full border border-cyan-400/30 text-cyan-300">
            Runs only while this window is open
          </span>
        </div>

        <div className="grid lg:grid-cols-3 gap-5 mb-5">
          {/* Trading bot / signal */}
          <Card title="XAUUSD AI Trading Bot · M15 (demo)" className="lg:col-span-2">
            <div className="flex items-center justify-between mb-3">
              <div className="text-2xl font-semibold tabular-nums text-slate-100">
                {price.toFixed(2)}
              </div>
              <SignalBadge type={signal.type} />
            </div>
            <Sparkline data={history} />
            <p className="text-[12px] text-slate-500 mt-2 mb-4">{signal.note}</p>
            <div className="grid grid-cols-3 gap-3 text-center mb-4">
              <div className="rounded-xl bg-black/25 py-3">
                <div className="text-[11px] text-slate-500">Entry</div>
                <div className="text-sm text-slate-200">{signal.entry ?? "—"}</div>
              </div>
              <div className="rounded-xl bg-black/25 py-3">
                <div className="text-[11px] text-slate-500">Stop Loss</div>
                <div className="text-sm text-slate-200">{signal.sl ?? "—"}</div>
              </div>
              <div className="rounded-xl bg-black/25 py-3">
                <div className="text-[11px] text-slate-500">Take Profit</div>
                <div className="text-sm text-slate-200">{signal.tp ?? "—"}</div>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-[12px] text-slate-500">
                Risk/Reward: <b className="text-slate-300">{signal.rr ?? "—"}</b>
              </span>
              <button
                onClick={logTrade}
                disabled={signal.type === "WAIT"}
                className="text-[12px] px-4 py-2 rounded-full disabled:opacity-30 text-[#06101F] font-medium"
                style={{ background: `linear-gradient(120deg, ${palette.cyan}, ${palette.electric})` }}
              >
                Log to Journal
              </button>
            </div>
          </Card>

          {/* MT5 integration panel */}
          <Card title="MT5 Integration">
            <div className="flex flex-col items-center justify-center h-full text-center gap-3 py-4">
              <span className="w-10 h-10 rounded-full border border-white/10 grid place-items-center text-slate-500">
                ⏻
              </span>
              <p className="text-[12px] text-slate-500 leading-relaxed">
                Not connected. Automatic execution activates only after secure
                credential setup and review — never simulated here.
              </p>
              <button className="text-[12px] px-4 py-2 rounded-full border border-white/15 text-slate-300">
                Connect Account
              </button>
            </div>
          </Card>
        </div>

        <div className="grid lg:grid-cols-3 gap-5">
          {/* Risk manager */}
          <Card title="Risk Manager">
            <div className="space-y-3 text-[13px]">
              <label className="block">
                <span className="text-slate-500">Account balance ($)</span>
                <input
                  type="number"
                  value={balance}
                  onChange={(e) => setBalance(+e.target.value)}
                  className="w-full mt-1 bg-white/[0.03] border border-white/10 rounded-lg px-3 py-2 outline-none focus:border-cyan-400/50"
                />
              </label>
              <label className="block">
                <span className="text-slate-500">Risk per trade (%)</span>
                <input
                  type="number"
                  value={riskPct}
                  onChange={(e) => setRiskPct(+e.target.value)}
                  className="w-full mt-1 bg-white/[0.03] border border-white/10 rounded-lg px-3 py-2 outline-none focus:border-cyan-400/50"
                />
              </label>
              <label className="block">
                <span className="text-slate-500">Stop distance (pips)</span>
                <input
                  type="number"
                  value={stopPips}
                  onChange={(e) => setStopPips(+e.target.value)}
                  className="w-full mt-1 bg-white/[0.03] border border-white/10 rounded-lg px-3 py-2 outline-none focus:border-cyan-400/50"
                />
              </label>
              <div className="flex items-center justify-between pt-2 border-t border-white/8">
                <span className="text-slate-500">Risk amount</span>
                <span className="text-slate-200">${riskAmount.toFixed(2)}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Suggested lot size</span>
                <span className="text-slate-200">{lotSize}</span>
              </div>
            </div>
          </Card>

          {/* Watchlist */}
          <Card title="Watchlist">
            <div className="space-y-2">
              {watchlist.map((w) => (
                <div key={w} className="flex items-center justify-between text-[13px] py-2 border-b border-white/5 last:border-0">
                  <span className="text-slate-300">{w}</span>
                  <span className="text-slate-500">demo</span>
                </div>
              ))}
            </div>
          </Card>

          {/* Journal */}
          <Card title="Trading Journal">
            {journal.length === 0 ? (
              <p className="text-[12px] text-slate-500">
                No entries yet. Log a signal to start your journal.
              </p>
            ) : (
              <div className="space-y-2 max-h-48 overflow-auto pr-1">
                {journal.map((j) => (
                  <div key={j.id} className="text-[12px] flex items-center justify-between border-b border-white/5 pb-2">
                    <span className={j.type === "BUY" ? "text-emerald-300" : "text-rose-300"}>
                      {j.type} @ {j.entry}
                    </span>
                    <span className="text-slate-500">{j.time}</span>
                  </div>
                ))}
              </div>
            )}
          </Card>
        </div>

        <p className="text-[11px] text-slate-500 mt-6 text-center">
          All prices, signals and journal entries on this screen are demo data for
          illustration only — no live market feed, no live broker connection, no
          guaranteed outcomes.
        </p>
      </div>
    </div>
  );
}
