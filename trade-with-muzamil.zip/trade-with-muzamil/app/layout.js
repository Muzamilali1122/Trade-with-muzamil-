import "./globals.css";

export const metadata = {
  title: "Trade With Muzamil — AI Trading Command Center",
  description:
    "Trade With Muzamil — premium trading education, AI tools, market insights and disciplined trading workflows.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
