TRADE WITH MUZAMIL — PROFESSIONAL DUAL-THEME V5

Includes:
- Premium fintech/trading visual system
- Dark + Light mode with automatic UI adaptation
- Green trading identity and green bullish candles preserved
- Responsive sticky navigation + mobile menu
- Hero / personal brand / learning offers
- Market Insights interface ready for live API integration
- Risk/Reward calculator
- Position-size calculator
- Trader checklist
- Structured trading learning roadmap
- FAQ section
- Trading proof gallery + lightbox
- 3 live-trading MP4 videos
- Professional bot/automation section
- WhatsApp + Telegram CTAs
- Accessibility-minded reduced-motion handling
- Scroll reveal and back-to-top interactions
- Risk disclosures and no-guaranteed-return wording

DEPLOYMENT:
Upload the entire extracted folder (or ZIP contents) to Netlify. Keep the assets folder beside index.html.


V6 VIP additions:
- Opening VIP promotional modal: Premium Course — 1 Month Free
- VIP ribbon/banner across the site
- Existing Muzamil portrait reused in a premium About section
- WhatsApp CTA connected to the existing official number
- VIP offer can be closed with X, backdrop or Escape; reappears in a new browser session
- Existing proof gallery remains ready for additional proof screenshots

IMPORTANT:
To add the new proof screens you mentioned, upload those screenshot/image files in the chat. They are not present in the V5 ZIP, so they have not been invented or substituted.


V7 proof gallery update:
- Added supplied TradingView Gold bullish setup screenshot as proof-08.
- Added supplied TradingView Gold bearish setup screenshot as proof-09.
- Added a dedicated TradingView Analysis label above the proof gallery.
- Existing proof screenshots remain unchanged.
